# Nirman Group of Company website

A responsive, single-page static website for Nirman Group of Company, focused on salons, cafés, restaurants, hotels, and local businesses.

## Run locally

Requirements: Node.js 22+ and npm 10+.

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

## Build locally

```bash
npm run build
npm run preview
```

The production files are written to `dist/`.

## Use this on GitHub Pages

1. Create a new GitHub repository, for example `nirman-group-website`.
2. Upload all files from this project to the repository root, including `.github/workflows/deploy-pages.yml`.
3. Commit and push to the `main` branch.
4. In GitHub, open **Settings → Pages**.
5. Under **Build and deployment**, select **GitHub Actions**.
6. Wait for the `Deploy website to GitHub Pages` workflow to complete.
7. Under **Custom domain**, enter `nirmangroup.in` and save.
8. Enable **Enforce HTTPS** after the DNS check succeeds.

The included `public/CNAME` file preserves the custom domain in the generated Pages artifact.

### DNS for `nirmangroup.in`

At your domain registrar, configure the apex domain using GitHub Pages' current documented A records, or follow the DNS records GitHub displays in **Settings → Pages**. For a `www` subdomain, use a CNAME pointing to your GitHub Pages hostname. Do not add both conflicting apex and `www` records. DNS changes can take time to propagate.

If your repository is not a user/organization Pages repository and you plan to use the default project URL instead of the custom domain, update `base` in `vite.config.ts` to `/<repository-name>/` before building. The current configuration is correct for `https://nirmangroup.in/`.

## Enquiry form

The form validates in the browser and creates a `mailto:` email draft addressed to `samratyashchauhan@zohomail.in`. The visitor must press **Send** in their own email application. The WhatsApp action creates a WhatsApp message from the entered form details. No enquiry data is stored by the website.

For production server-side delivery, add a protected endpoint with server-side validation, rate limiting, spam protection, and a documented retention policy before replacing the email-draft flow.

## Project structure

- `index.html` — the complete website, styles, accessible markup, and interactions
- `public/yash-chauhan.jpg` — founder portrait
- `public/og-cover.svg` — social preview artwork
- `public/CNAME` — custom domain for GitHub Pages
- `.github/workflows/deploy-pages.yml` — automatic GitHub Pages deployment
- `vite.config.ts` — local preview configuration
- `package.json` — static-site tooling
