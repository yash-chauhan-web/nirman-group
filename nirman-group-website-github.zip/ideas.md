# Nirman Group website design brief

## Selected direction

**Hospitality editorial** — a warm, mobile-first service website for salons, cafés, restaurants, hotels, and other local businesses.

- **Palette:** soft ivory, deep forest green, and restrained antique gold.
- **Layout:** sticky navigation, clear conversion-led hero, comparison block, service grid, industry grid, process steps, founder story, FAQs, and contact form.
- **Signature element:** NGC geometric monogram with gold and green linework.
- **Voice:** practical, confident, local-business focused, and human-led.
- **Interaction:** responsive menu, animated reveals, service-to-form preselection, WhatsApp handoff, and email-draft enquiry.
- **Accessibility:** semantic headings, visible focus states, labelled inputs, reduced-motion support, keyboard-friendly details accordions, and minimum touch target sizes.
- **Technical direction:** one static HTML source rendered directly by Vite; no duplicate React implementation.
